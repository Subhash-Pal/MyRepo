Realtime Chat Application in Go And ReactJS
=============================================

Currently Under Construction

NOTE: at all stages of this project, in order to test server and frontend together, navigate to /frontend, and run $ npm start. This will begin your front end test server on localhost:3000. Then, navigate to /backend and run $ go run main.go. Then, in the browser of your choice, go to localhost:3000.
