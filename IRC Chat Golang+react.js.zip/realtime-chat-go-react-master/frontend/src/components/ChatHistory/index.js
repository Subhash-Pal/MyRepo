import ChatHistory from './ChatHistory.jsx'

export default ChatHistory;