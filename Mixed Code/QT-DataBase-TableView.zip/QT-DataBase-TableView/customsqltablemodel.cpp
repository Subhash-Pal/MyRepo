// customsqltablemodel.cpp
#include "customsqltablemodel.h"

CustomSqlTableModel::CustomSqlTableModel(QObject *parent, QSqlDatabase db)
    : QSqlTableModel(parent, db)
{
}

QHash<int, QByteArray> CustomSqlTableModel::roleNames() const {
    QHash<int, QByteArray> roles;
    roles[Qt::UserRole + 1] = "id";
    roles[Qt::UserRole + 2] = "name";
    roles[Qt::UserRole + 3] = "email";
    roles[Qt::UserRole + 4] = "age";
    return roles;
}

QVariant CustomSqlTableModel::data(const QModelIndex &index, int role) const {
    if (role == Qt::UserRole + 1)  // id
        return QSqlTableModel::data(index.siblingAtColumn(0));
    else if (role == Qt::UserRole + 2)  // name
        return QSqlTableModel::data(index.siblingAtColumn(1));
    else if (role == Qt::UserRole + 3)  // email
        return QSqlTableModel::data(index.siblingAtColumn(2));
    else if (role == Qt::UserRole + 4)  // age
        return QSqlTableModel::data(index.siblingAtColumn(3));

    return QSqlTableModel::data(index, role);
}
