/*
#include <QCoreApplication>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QSqlTableModel>
#include <QDebug>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    // Initialize the database connection
    QSqlDatabase db = QSqlDatabase::addDatabase("QPSQL");  // QPSQL is the driver for PostgreSQL
    db.setHostName("localhost");
    db.setDatabaseName("postgres");  // Replace with your database name
    db.setPort(5432);                 // Default PostgreSQL port
    db.setUserName("postgres");       // Username
    db.setPassword("root");           // Password

    // Open the connection
    if (!db.open()) {
        qDebug() << "Error: Unable to connect to the database!" << db.lastError();
        return -1;
    }

    qDebug() << "Connected to the database successfully!";

    // Step 1: Set up the QSqlTableModel
    QSqlTableModel model(nullptr, db);
    model.setTable("users");  // Specify your table name
    model.select();           // Query the data

    // Step 2: Display the data in the console
    if (model.rowCount() == 0) {
        qDebug() << "No data found in the 'users' table.";
    } else {
        qDebug() << "ID | Name    | Email              | Age";
        qDebug() << "-------------------------------------------";

        for (int row = 0; row < model.rowCount(); ++row) {
            QString id = model.data(model.index(row, 0)).toString();
            QString name = model.data(model.index(row, 1)).toString();
            QString email = model.data(model.index(row, 2)).toString();
            QString age = model.data(model.index(row, 3)).toString();

            qDebug() << id << "| " << name << "| " << email << "| " << age;
        }
    }

    // Close the database connection
    db.close();

    return 0;
}
*/
