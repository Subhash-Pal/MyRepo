// customsqltablemodel.h
#ifndef CUSTOMSQLTABLEMODEL_H
#define CUSTOMSQLTABLEMODEL_H

#include <QSqlTableModel>
#include <QHash>
#include <QByteArray>

class CustomSqlTableModel : public QSqlTableModel
{
    Q_OBJECT

public:
    explicit CustomSqlTableModel(QObject *parent = nullptr, QSqlDatabase db = QSqlDatabase());

    // Override roleNames to provide custom role names
    QHash<int, QByteArray> roleNames() const override;

    // Override data function to return data based on the custom roles
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
};

#endif // CUSTOMSQLTABLEMODEL_H
