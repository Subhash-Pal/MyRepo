// main.cpp
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QSqlDatabase>
#include <QSqlError>
#include <QDebug>
#include "customsqltablemodel.h"

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    // Initialize the database connection
    QSqlDatabase db = QSqlDatabase::addDatabase("QPSQL");  // QPSQL is the driver for PostgreSQL
    db.setHostName("localhost");
    db.setDatabaseName("postgres");  // Replace with your database name
    db.setPort(5432);                 // Default PostgreSQL port
    db.setUserName("postgres");       // Username
    db.setPassword("root");           // Password

    // Open the connection
    if (!db.open()) {
        qDebug() << "Error: Unable to connect to the database!" << db.lastError();
        return -1;
    }

    qDebug() << "Connected to the database successfully!";

    // Set up the custom model
    CustomSqlTableModel *model = new CustomSqlTableModel(nullptr, db);
    model->setTable("users");  // Replace with your table name
    model->select();           // Query the data

    // Set up QML engine
    QQmlApplicationEngine engine;
    engine.rootContext()->setContextProperty("usersModel", model);  // Expose model to QML

    // Load QML file (use QStringLiteral instead of _qs)
    const QUrl url(QStringLiteral("qrc:/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);

    engine.load(url);

    return app.exec();
}
