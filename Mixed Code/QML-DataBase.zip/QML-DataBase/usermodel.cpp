#include "usermodel.h"

UserModel::UserModel(QObject* parent) : QSqlQueryModel(parent)
{
}
