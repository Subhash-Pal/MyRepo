#ifndef DBMANAGER_H
#define DBMANAGER_H

#include <QObject>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include "usermodel.h"

class DbManager : public QObject {
    Q_OBJECT
    Q_PROPERTY(UserModel* userModel READ userModel CONSTANT)
public:
    explicit DbManager(QObject* parent = nullptr);

    Q_INVOKABLE bool insertUser(const QString& name, int age);
    Q_INVOKABLE void loadUsers();  // Load users into the model

    UserModel* userModel();  // Expose the UserModel to QML

private:
    QSqlDatabase db;
    UserModel m_userModel;
};

#endif // DBMANAGER_H
