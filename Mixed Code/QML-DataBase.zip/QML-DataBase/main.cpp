#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include "DbManager.h"

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    // Create an instance of DbManager
    DbManager dbManager;

    // Expose dbManager and userModel to QML
    engine.rootContext()->setContextProperty("dbManager", &dbManager);
    engine.rootContext()->setContextProperty("userModel", dbManager.userModel());

    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));

    if (engine.rootObjects().isEmpty())
        return -1;

    return app.exec();
}
