#include "DbManager.h"
#include <QDebug>

DbManager::DbManager(QObject* parent) : QObject(parent), m_userModel(new UserModel(this))
{
    db = QSqlDatabase::addDatabase("QPSQL");
    db.setHostName("localhost");
    db.setDatabaseName("postgres");
    db.setPort(5432);
    db.setUserName("postgres");
    db.setPassword("root");

    if (!db.open()) {
        qDebug() << "Error: Unable to connect to the database!" << db.lastError();
    } else {
        qDebug() << "Connected to the database successfully!";
        loadUsers();
    }
}

bool DbManager::insertUser(const QString& name, int age)
{
    QSqlQuery query;
    query.prepare("INSERT INTO users (name, age) VALUES (:name, :age)");
    query.bindValue(":name", name);
    query.bindValue(":age", age);

    if (query.exec()) {
        loadUsers();
        return true;
    } else {
        qDebug() << "Insert error:" << query.lastError();
        return false;
    }
}

void DbManager::loadUsers()
{
    QSqlQuery query("SELECT id, name, age FROM users ORDER BY id");
    m_userModel.setQuery(query);
    if (m_userModel.lastError().isValid()) {
        qDebug() << "Query error:" << m_userModel.lastError();
    }
}

UserModel* DbManager::userModel()
{
    return &m_userModel;
}
